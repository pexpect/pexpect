#!/bin/sh
#
# Refresh the font cache.
# This is here mainly to support the ProggyClean font.
# Example:
#     xterm -font "-windows-proggycleanszbp-medium-r-normal--13-80-96-96-c-70-iso8859-1"
#
# Noah Spurrier

# print X font path:
#xset q

# rebuild font.dir file
mkfontdir ~/.fonts
# add to font path
xset fp+ ~/.fonts > /dev/null 2>&1
# tell X to reread fonts
xset fp rehash > /dev/null 2>&1

